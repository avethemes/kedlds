<!DOCTYPE html>
<html lang="en">

<?php include './partials/head.php' ?>

  <body>

    <!-- Cursor start -->
    <<?php include './partials/cursor_start.php' ?>
    <!-- Cursor end -->

    <!-- back to top start -->
    <?php include './partials/back_to_start.php' ?>
    <!-- back to top end -->

    <!-- modal-search-start -->
    <?php include './partials/modal-search-start.php' ?>
    <!-- modal-search-end -->
    
    <!-- sidebar-information-area-start -->
    <?php include './partials/sidebar_information.php' ?>
    <!-- sidebar-information-area-end -->


    <div class="has-smooth" id="has_smooth"></div>
    
    <div id="smooth-wrapper">
        <div id="smooth-content">
            <div class="body-wrapper">

                <header class="h5_header-area">
                    <div class="h5_header-top d-sm-flex align-items-center d-none">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-6 col-lg-7">
                                    <div class="h5_header-top-text">
                                        <p>Create an account to avail a 34% bonus discount at checkout.</p>
                                        <a href="#">Learn More<i class="fa-light fa-angle-right"></i></a>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-5 d-none d-lg-block">
                                    <div class="h5_header-top-right">
                                        <div class="h5_header-top-language">
                                            <select name="select" class="h5_header-top-language-option has-nice-select">
                                                <option value="1">English</option>
                                                <option value="2">Bangla</option>
                                                <option value="3">Arabic</option>
                                                <option value="4">Urdu</option>
                                            </select>
                                        </div>
                                        <div class="h5_header-top-currency">
                                            <select name="select" class="h5_header-top-currency-option has-nice-select">
                                                <option value="1">$USD</option>
                                                <option value="2">৳Taka</option>
                                                <option value="3">€Euro</option>
                                            </select>
                                        </div>
                                        <div class="h5_header-top-account">
                                            <a href="#">
                                                <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.0127 8C8.94569 8 10.5127 6.433 10.5127 4.5C10.5127 2.567 8.94569 1 7.0127 1C5.0797 1 3.5127 2.567 3.5127 4.5C3.5127 6.433 5.0797 8 7.0127 8Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M13.026 15C13.026 12.291 10.331 10.1 7.013 10.1C3.695 10.1 1 12.291 1 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                My Account
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="h5_header-bottom header-sticky">
                        <div class="container">
                            <div class="row align-items-center justify-content-between">
                                <div class="col-xl-2 col-lg-2 col-4">
                                    <div class="h5_header-logo">
                                        <a href="index.php"><img src="assets/images/logo/logo.png" alt="Image Not Found"></a>
                                    </div>
                                </div>
                                <div class="col-xl-7 col-lg-6 d-none d-lg-block text-center">
                                    <div class="h5_header-menu ">
                                        <nav class="h5_header-nav-menu" id="mobile-menu">
                                            <ul>
                                                <li class="menu-has-child">
                                                    <a href="index.php">Home</a>
                                                    <ul class="submenu">
                                                        <li><a href="index.php">AI Doodle</a></li>
                                                        <li><a href="index-2.php">AI Co-Pilot</a></li>
                                                        <li><a href="index-3.php">AI Image Generator</a></li>
                                                        <li><a href="index-4.php">AI Text Generator</a></li>
                                                        <li><a href="index-5.php">AI Photostock</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="about.php">About</a></li>
                                                <li class="menu-has-child">
                                                    <a href="#">Pages</a>
                                                    <ul class="submenu">
                                                        <li><a href="service.php">Services</a></li>
                                                        <li><a href="team.php">Team</a></li>
                                                        <li><a href="work.php">Portfolio</a></li>
                                                        <li><a href="price.php">Pricing</a></li>
                                                        <li><a href="faq.php">FAQ's</a></li>
                                                        <li><a href="testimonial.php">Testimonials</a></li>
                                                        <li><a href="wishlist.php">Wishlist</a></li>
                                                        <li><a href="cart.php">Cart</a></li>
                                                        <li><a href="checkout.php">Checkout</a></li>
                                                        <li><a href="login.php">Login</a></li>
                                                        <li><a href="404.php">404</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-has-child">
                                                    <a href="shop.php">Shop</a>
                                                    <ul class="submenu">
                                                        <li><a href="shop.php">Shop</a></li>
                                                        <li><a href="shop-details.php">Shop Details</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-has-child">
                                                    <a href="blog.php">Blog</a>
                                                    <ul class="submenu">
                                                        <li><a href="blog.php">Blog</a></li>
                                                        <li><a href="blog-details.php">Blog Details</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="contact.php">Contact</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-8">
                                    <div class="h5_header-action-wrap d-flex align-items-center justify-content-end">
                                        <div class="h5_header-action d-none d-sm-flex">
                                            <div class="h5_header-action-inner">
                                                <a class="h5_header-action-search" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#search-modal"><i class="fa-light fa-search"></i></a>
                                                <a href="cart.php" class="h5_header-action-cart"><i class="fa-light fa-shopping-bag"></i><span>12</span></a>
                                            </div>
                                            <a href="#" class="h5_header-action-btn">
                                                Get Started<i class="fa-light fa-angle-right"></i>                                
                                            </a>
                                        </div>
                                        <div class="header-menu-bar d-lg-none ml-10">
                                            <span class="header-menu-bar-icon side-toggle">
                                                <i class="fa-light fa-bars"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <main>

                    <?php $subTitle="Checkout"?>
                    <!-- breadcrumb area start -->
                    <?php include './partials/breadcrumb.php' ?>
                    <!-- breadcrumb area end -->

                    <!-- checkout area start -->
                    <section class="checkout-area pt-140 mb-100">
                        <div class="container">
                            <div class="checkout-top mb-60">
                                <div class="checkout-top-item  tp_has_fade_anim" data-fade-from="left">
                                    <span><a href="cart.php">01</a></span>
                                    <p><a href="cart.php">Shopping Cart</a></p>
                                </div>
                                <div class="checkout-top-item  tp_has_fade_anim" data-fade-from="left" data-delay=".8">
                                    <span><a href="#">02</a></span>
                                    <p><a href="#">Payment & Delivery Options</a></p>
                                </div>
                                <div class="checkout-top-item last-item  tp_has_fade_anim" data-fade-from="left" data-delay="1.1">
                                    <span>03</span>
                                    <p>Order Received</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-8">
                                    <div class="checkout-left mr-50 mb-40">
                                        <h2 class="checkout-title tp_has_text_reveal_anim">Billing details</h2>
                                        <div class="checkout-form tp_fade_right">
                                            <form action="#">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="text" placeholder="Fast Name">
                                                            <i class="fa-light fa-user"></i>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="checkout-form-item mb-25">    
                                                            <input type="text" placeholder="Last Name">
                                                            <i class="fa-light fa-user"></i>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="email" placeholder="Your Email">
                                                            <i class="fa-light fa-envelope"></i>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">    
                                                            <input type="text" placeholder="Phone Number">
                                                            <i class="fa-light fa-phone"></i>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="text" placeholder="Company Name (optional)">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="text" placeholder="Town / City">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="text" placeholder="State">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="text" placeholder="ZIP Code">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item mb-25">
                                                            <input type="text" placeholder="Address">
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="checkout-form-item">
                                                            <textarea name="message" placeholder="Additional Information"></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="checkout-right mb-40">
                                        <div class="checkout-order-wrap mb-30">
                                            <h2 class="checkout-title tp_has_text_reveal_anim">Your order</h2>
                                            <div class="checkout-order tp_fade_left">
                                                <h5>Total Cart (05)</h5>
                                                <ul>
                                                    <li>Subtotal : <span>$755.00</span></li>
                                                    <li>Delivery : <span>$55.00</span></li>
                                                    <li>Discount : <span>$75.00</span></li>
                                                    <li>Total : <span>$856.00</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="checkout-payment-wrap">
                                            <h2 class="checkout-title tp_has_text_reveal_anim">Payment</h2>
                                            <div class="checkout-payment tp_fade_left">
                                                <div class="checkout-payment-item">
                                                    <label class="condition-checkbox">
                                                        Check payments
                                                        <input type="checkbox">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                    <p>Please send a check to Store Name, Store Street, Town, Store State / County, Store Postcode.</p>
                                                </div>
                                                <div class="checkout-payment-item">
                                                    <label class="condition-checkbox">
                                                        Check on delivery
                                                        <input type="checkbox">
                                                        <span class="checkmark"></span>
                                                    </label>
                                                </div>
                                                <div class="checkout-payment-text">
                                                    <p>Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <a href="#">Privacy policy.</a></p>
                                                </div>
                                                <a href="#" class="checkout-payment-btn">Place Order</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- checkout area end -->
                </main>
            
                <!-- footer area start -->
                <?php include './partials/footer.php' ?>
                <!-- footer area end -->

            </div>
        </div>
    </div>


    <!-- jQuery Js -->
        <?php include './partials/script.php' ?>
  </body>
</html>
