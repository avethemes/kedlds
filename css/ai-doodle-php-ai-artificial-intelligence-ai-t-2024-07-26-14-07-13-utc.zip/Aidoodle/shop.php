<!DOCTYPE html>
<html lang="en">

<?php include './partials/head.php' ?>

  <body>

    <!-- Cursor start -->
    <?php include './partials/Cursor_start.php' ?>
    <!-- Cursor end -->

    <!-- back to top start -->
    <?php include './partials/back_to_start.php' ?>
    <!-- back to top end -->

    <!-- modal-search-start -->
    <?php include './partials/modal-search-start.php' ?>
    <!-- modal-search-end -->
    
    <!-- sidebar-information-area-start -->
    <?php include './partials/sidebar_information.php' ?>
    <!-- sidebar-information-area-end -->

    <div class="has-smooth" id="has_smooth"></div>
    
    <div id="smooth-wrapper">
        <div id="smooth-content">
            <div class="body-wrapper">
                <header class="h5_header-area">
                    <div class="h5_header-top d-sm-flex align-items-center d-none">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-xl-6 col-lg-7">
                                    <div class="h5_header-top-text">
                                        <p>Create an account to avail a 34% bonus discount at checkout.</p>
                                        <a href="#">Learn More<i class="fa-light fa-angle-right"></i></a>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-5 d-none d-lg-block">
                                    <div class="h5_header-top-right">
                                        <div class="h5_header-top-language">
                                            <select name="select" class="h5_header-top-language-option has-nice-select">
                                                <option value="1">English</option>
                                                <option value="2">Bangla</option>
                                                <option value="3">Arabic</option>
                                                <option value="4">Urdu</option>
                                            </select>
                                        </div>
                                        <div class="h5_header-top-currency">
                                            <select name="select" class="h5_header-top-currency-option has-nice-select">
                                                <option value="1">$USD</option>
                                                <option value="2">৳Taka</option>
                                                <option value="3">€Euro</option>
                                            </select>
                                        </div>
                                        <div class="h5_header-top-account">
                                            <a href="#">
                                                <svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M7.0127 8C8.94569 8 10.5127 6.433 10.5127 4.5C10.5127 2.567 8.94569 1 7.0127 1C5.0797 1 3.5127 2.567 3.5127 4.5C3.5127 6.433 5.0797 8 7.0127 8Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    <path d="M13.026 15C13.026 12.291 10.331 10.1 7.013 10.1C3.695 10.1 1 12.291 1 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                My Account
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="h5_header-bottom header-sticky">
                        <div class="container">
                            <div class="row align-items-center justify-content-between">
                                <div class="col-xl-2 col-lg-2 col-4">
                                    <div class="h5_header-logo">
                                        <a href="index.php"><img src="assets/images/logo/logo.png" alt="Image Not Found"></a>
                                    </div>
                                </div>
                                <div class="col-xl-7 col-lg-6 d-none d-lg-block text-center">
                                    <div class="h5_header-menu ">
                                        <nav class="h5_header-nav-menu" id="mobile-menu">
                                            <ul>
                                                <li class="menu-has-child">
                                                    <a href="index.php">Home</a>
                                                    <ul class="submenu">
                                                        <li><a href="index.php">AI Doodle</a></li>
                                                        <li><a href="index-2.php">AI Co-Pilot</a></li>
                                                        <li><a href="index-3.php">AI Image Generator</a></li>
                                                        <li><a href="index-4.php">AI Text Generator</a></li>
                                                        <li><a href="index-5.php">AI Photostock</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="about.php">About</a></li>
                                                <li class="menu-has-child">
                                                    <a href="#">Pages</a>
                                                    <ul class="submenu">
                                                        <li><a href="service.php">Services</a></li>
                                                        <li><a href="team.php">Team</a></li>
                                                        <li><a href="work.php">Portfolio</a></li>
                                                        <li><a href="price.php">Pricing</a></li>
                                                        <li><a href="faq.php">FAQ's</a></li>
                                                        <li><a href="testimonial.php">Testimonials</a></li>
                                                        <li><a href="wishlist.php">Wishlist</a></li>
                                                        <li><a href="cart.php">Cart</a></li>
                                                        <li><a href="checkout.php">Checkout</a></li>
                                                        <li><a href="login.php">Login</a></li>
                                                        <li><a href="404.php">404</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-has-child">
                                                    <a href="shop.php">Shop</a>
                                                    <ul class="submenu">
                                                        <li><a href="shop.php">Shop</a></li>
                                                        <li><a href="shop-details.php">Shop Details</a></li>
                                                    </ul>
                                                </li>
                                                <li class="menu-has-child">
                                                    <a href="blog.php">Blog</a>
                                                    <ul class="submenu">
                                                        <li><a href="blog.php">Blog</a></li>
                                                        <li><a href="blog-details.php">Blog Details</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="contact.php">Contact</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-lg-4 col-8">
                                    <div class="h5_header-action-wrap d-flex align-items-center justify-content-end">
                                        <div class="h5_header-action d-none d-sm-flex">
                                            <div class="h5_header-action-inner">
                                                <a class="h5_header-action-search" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#search-modal"><i class="fa-light fa-search"></i></a>
                                                <a href="cart.php" class="h5_header-action-cart"><i class="fa-light fa-shopping-bag"></i><span>12</span></a>
                                            </div>
                                            <a href="#" class="h5_header-action-btn">
                                                Get Started<i class="fa-light fa-angle-right"></i>                                
                                            </a>
                                        </div>
                                        <div class="header-menu-bar d-lg-none ml-10">
                                            <span class="header-menu-bar-icon side-toggle">
                                                <i class="fa-light fa-bars"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <main>
                    <?php $subTitle='Shop' ?>
                    <!-- breadcrumb area start -->
                    <?php include './partials/breadcrumb.php' ?>
                    <!-- breadcrumb area end -->

                    <!-- shop area start -->
                    <section class="h5_shop-area pb-140 pt-140">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/1.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay=".2">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/2.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay=".4">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/3.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay=".6">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/4.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay=".8">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/5.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="1">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/6.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="1.2">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/7.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="1.4">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/8.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="1.6">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/9.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="1.8">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/10.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="2">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/11.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-md-4 col-sm-6 tp_fade_left" data-fade-from="bottom" data-delay="2.1">
                                    <div class="h5_shop-item mb-30">
                                        <div class="h5_shop-img">
                                            <img src="assets/images/gallery/12.png" alt="">
                                            <div class="h5_shop-premium-icon">
                                                <svg width="21" height="16" viewBox="0 0 21 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M10.1197 0.0265846C10.0591 0.0482168 9.95525 0.100135 9.88603 0.143399C9.81681 0.190991 9.06832 1.26829 8.04727 2.79554C7.09977 4.21463 6.28206 5.41739 6.22582 5.46931C5.95758 5.71159 5.47301 5.77216 5.17016 5.5991C5.07497 5.54286 4.13612 4.85062 3.08046 4.0632C2.0248 3.27145 1.10326 2.58354 1.02538 2.54027C0.847992 2.43211 0.545138 2.42779 0.346119 2.53595C0.190366 2.61815 0 2.91668 0 3.07676C0 3.18492 1.24603 11.3187 1.27631 11.3966C1.30227 11.4788 19.4649 11.4788 19.4908 11.3966C19.5211 11.3187 20.7672 3.18492 20.7672 3.07676C20.7672 2.91668 20.5768 2.61815 20.421 2.53595C20.2263 2.42779 19.9192 2.43211 19.7461 2.53595C19.6682 2.58354 18.7164 3.28876 17.6218 4.10646C16.5315 4.9285 15.571 5.62074 15.4932 5.64669C15.1773 5.75918 14.775 5.68131 14.5413 5.46931C14.4851 5.41739 13.6631 4.21463 12.7199 2.79554C11.3873 0.801026 10.9633 0.195317 10.8422 0.121767C10.6735 0.0136051 10.3014 -0.0339861 10.1197 0.0265846Z" fill="currentColor"/>
                                                    <path d="M1.26298 14.1223C1.27596 15.2212 1.28029 15.2905 1.37114 15.4635C1.48796 15.6842 1.72591 15.8789 1.94224 15.9481C2.1802 16.0173 18.5862 16.0173 18.8242 15.9481C19.0405 15.8789 19.2785 15.6842 19.3953 15.4635C19.4862 15.2905 19.4905 15.2212 19.5035 14.1223L19.5164 12.9671H10.3832H1.25L1.26298 14.1223Z" fill="currentColor"/>
                                                </svg>
                                            </div>
                                            <div class="h5_shop-img-icon">
                                                <a href="#"><i class="fa-light fa-eye"></i></a>
                                                <a href="#"><i class="fa-light fa-heart"></i></a>
                                            </div>
                                        </div>
                                        <div class="h5_shop-content">
                                            <h5 class="h5_shop-content-title"><a href="#">CreatBot Mindful Arts</a></h5>
                                            <div class="h5_shop-content-bottom">
                                                <a href="#" class="h5_shop-content-price h5_shop-content-bottom-link">$12.05</a>
                                                <a href="#" class="h5_shop-content-cart"><i class="fa-light fa-shopping-cart"></i> Add To Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="pagination-area pt-30 d-flex justify-content-center tp_fade_bottom">
                                        <span><i class="fa-light fa-arrow-left"></i></span>
                                            <ul>
                                                <li><a href="#" class="active">01</a></li>
                                                <li><a href="#">02</a></li>
                                                <li><a href="#">03</a></li>
                                            </ul>
                                        <span><i class="fa-light fa-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- shop area end -->
                </main>
            
                <!-- footer area start -->
                <?php include './partials/footer.php' ?>
                <!-- footer area end -->

            </div>
        </div>
    </div>


    <!-- jQuery Js -->
    <?php include './partials/script.php' ?>
 
  </body>
</html>
