<head>
    <meta charset="UTF-8">
    <meta name="description" content="html template">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="author" content="Asad">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>AI Doodle - AI Artificial Tntelligence & AI Technology Startups</title>

    <link rel="icon" href="assets/images/favicon.png">
    <link rel="apple-touch-icon" href="assets/images/favicon.png">
    <link rel="stylesheet" href="assets/css/all.min.css"> 
    <link rel="stylesheet" href="assets/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css"> 
    <link rel="stylesheet" href="assets/css/meanmenu.css"> 
    <link rel="stylesheet" href="assets/css/magnific-popup.css"> 
    <link rel="stylesheet" href="assets/css/nice-select.css"> 
    <link rel="stylesheet" href="assets/css/backtotop.css"> 
    <link rel="stylesheet" href="assets/css/main.css"> 

  </head>